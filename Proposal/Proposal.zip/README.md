DATASET:
Dataset can be downloaded from the Kaggle competition. Please download train.zip, test.zip and labesl.csv.zip

https://www.kaggle.com/c/dog-breed-identification/data